/**
 * FinBook — Reports API Routes
 * GET /api/reports/trial-balance?period=2025-01
 * GET /api/reports/pnl?period=2025-01
 * GET /api/reports/balance-sheet?period=2025-01
 * GET /api/reports/budget?period=2025-01
 * GET /api/reports/export?period=2025-01  → .xlsx download
 */

'use strict';

const express  = require('express');
const router   = express.Router();
const ExcelJS  = require('exceljs');
const engine   = require('../engine/accountingEngine');

// Helper — require a period query param
function requirePeriod(req, res) {
  const { period } = req.query;
  if (!period || !/^\d{4}-\d{2}$/.test(period)) {
    res.status(400).json({ error: 'period query param required (format: YYYY-MM).' });
    return null;
  }
  return period;
}

// ─── Trial Balance ────────────────────────────────────────────
router.get('/trial-balance', async (req, res) => {
  const period = requirePeriod(req, res);
  if (!period) return;
  try {
    const data = await engine.buildTrialBalance(req.user.id, period, req.app.locals.db);
    return res.json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── P&L ─────────────────────────────────────────────────────
router.get('/pnl', async (req, res) => {
  const period = requirePeriod(req, res);
  if (!period) return;
  try {
    const data = await engine.buildProfitAndLoss(req.user.id, period, req.app.locals.db);
    return res.json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── Balance Sheet ────────────────────────────────────────────
router.get('/balance-sheet', async (req, res) => {
  const period = requirePeriod(req, res);
  if (!period) return;
  try {
    const data = await engine.buildBalanceSheet(req.user.id, period, req.app.locals.db);
    return res.json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── Budget vs Actual ─────────────────────────────────────────
router.get('/budget', async (req, res) => {
  const period = requirePeriod(req, res);
  if (!period) return;
  try {
    const data = await engine.buildBudgetReport(req.user.id, period, req.app.locals.db);
    return res.json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── Excel Export ─────────────────────────────────────────────
// Produces a .xlsx with 5 sheets matching your original cashbook format:
//   1. Cash Book     2. Journals    3. Trial Balance
//   4. P&L           5. Balance Sheet
router.get('/export', async (req, res) => {
  const period = requirePeriod(req, res);
  if (!period) return;

  try {
    const exportData = await engine.buildExcelExport(
      req.user.id, period, req.app.locals.db
    );

    const wb = new ExcelJS.Workbook();
    wb.creator  = 'FinBook';
    wb.created  = new Date();
    wb.modified = new Date();

    // ── Styles ──────────────────────────────────────────────
    const headerFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1a1a20' } };
    const headerFont = { bold: true, color: { argb: 'FFFFFFFF' }, size: 10 };
    const moneyFmt   = '#,##0.00';
    const debitColor = { argb: 'FFFFE5E5' };
    const creditColor= { argb: 'FFE5F9EE' };

    function styleHeader(ws, row) {
      row.eachCell(cell => {
        cell.fill = headerFill;
        cell.font = headerFont;
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
      });
    }

    // ════════════════════════════════════════════════════════
    // SHEET 1 — CASH BOOK
    // ════════════════════════════════════════════════════════
    const cbSheet = wb.addWorksheet('Cash Book', {
      views: [{ state: 'frozen', ySplit: 2 }],
    });
    cbSheet.columns = [
      { header: 'Date',            key: 'txn_date',        width: 13 },
      { header: 'Description',     key: 'description',     width: 28 },
      { header: 'Comment',         key: 'comment',         width: 22 },
      { header: 'Category',        key: 'category',        width: 20 },
      { header: 'Debit (DR)',       key: 'debit_amount',    width: 14 },
      { header: 'Credit (CR)',      key: 'credit_amount',   width: 14 },
      { header: 'Running Balance',  key: 'running_balance', width: 16 },
    ];
    styleHeader(cbSheet, cbSheet.getRow(1));

    exportData.cashBook.forEach(row => {
      const r = cbSheet.addRow({
        txn_date:        row.txn_date,
        description:     row.description,
        comment:         row.comment || '',
        category:        row.category || '',
        debit_amount:    row.debit_amount  ? parseFloat(row.debit_amount)  : null,
        credit_amount:   row.credit_amount ? parseFloat(row.credit_amount) : null,
        running_balance: row.running_balance ? parseFloat(row.running_balance) : null,
      });

      // Format money columns
      ['debit_amount', 'credit_amount', 'running_balance'].forEach(key => {
        const cell = r.getCell(key);
        cell.numFmt = moneyFmt;
      });

      // Color DR rows red-tint, CR rows green-tint
      if (row.debit_amount) {
        r.getCell('debit_amount').fill = { type: 'pattern', pattern: 'solid', fgColor: debitColor };
      } else {
        r.getCell('credit_amount').fill = { type: 'pattern', pattern: 'solid', fgColor: creditColor };
      }

      // Red balance if negative
      const bal = parseFloat(row.running_balance);
      if (bal < 0) {
        r.getCell('running_balance').font = { color: { argb: 'FFCC0000' }, bold: true };
      }
    });

    // Totals row
    const cbTotals = cbSheet.addRow({
      description:     'TOTAL',
      debit_amount:    exportData.cashBook.reduce((s, r) => s + parseFloat(r.debit_amount || 0), 0),
      credit_amount:   exportData.cashBook.reduce((s, r) => s + parseFloat(r.credit_amount || 0), 0),
    });
    cbTotals.font = { bold: true };
    cbTotals.getCell('debit_amount').numFmt  = moneyFmt;
    cbTotals.getCell('credit_amount').numFmt = moneyFmt;

    // ════════════════════════════════════════════════════════
    // SHEET 2 — TRIAL BALANCE
    // ════════════════════════════════════════════════════════
    const tbSheet = wb.addWorksheet('Trial Balance', {
      views: [{ state: 'frozen', ySplit: 1 }],
    });
    tbSheet.columns = [
      { header: 'Account',      key: 'accountName', width: 30 },
      { header: 'Type',         key: 'accountType', width: 14 },
      { header: 'Debit (DR)',   key: 'totalDr',     width: 16 },
      { header: 'Credit (CR)',  key: 'totalCr',     width: 16 },
      { header: 'Net Balance',  key: 'netBalance',  width: 16 },
    ];
    styleHeader(tbSheet, tbSheet.getRow(1));

    exportData.trialBalance.accounts.forEach(a => {
      const r = tbSheet.addRow(a);
      ['totalDr', 'totalCr', 'netBalance'].forEach(k => {
        r.getCell(k).numFmt = moneyFmt;
      });
    });

    // Totals
    const tbTotals = tbSheet.addRow({
      accountName: 'TOTAL',
      totalDr:     exportData.trialBalance.totals.totalDr,
      totalCr:     exportData.trialBalance.totals.totalCr,
    });
    tbTotals.font = { bold: true };
    ['totalDr','totalCr'].forEach(k => tbTotals.getCell(k).numFmt = moneyFmt);
    tbSheet.addRow({
      accountName: exportData.trialBalance.totals.balanced ? '✓ Balanced' : '✗ NOT BALANCED',
    }).font = { bold: true, color: { argb: exportData.trialBalance.totals.balanced ? 'FF006600' : 'FFCC0000' }};

    // ════════════════════════════════════════════════════════
    // SHEET 3 — P&L
    // ════════════════════════════════════════════════════════
    const pnlSheet = wb.addWorksheet('Profit & Loss');
    pnlSheet.addRow([`Profit and Loss for the period: ${period}`]).font = { bold: true, size: 13 };
    pnlSheet.addRow([]);

    pnlSheet.addRow(['INCOME']).font = { bold: true };
    exportData.profitAndLoss.income.accounts.forEach(a => {
      const r = pnlSheet.addRow(['  ' + a.accountName, a.netBalance]);
      r.getCell(2).numFmt = moneyFmt;
    });
    const incomeRow = pnlSheet.addRow(['Total Income', exportData.profitAndLoss.income.total]);
    incomeRow.font = { bold: true };
    incomeRow.getCell(2).numFmt = moneyFmt;
    incomeRow.getCell(2).font  = { bold: true, color: { argb: 'FF006600' } };

    pnlSheet.addRow([]);
    pnlSheet.addRow(['EXPENSES']).font = { bold: true };
    exportData.profitAndLoss.expenses.accounts.forEach(a => {
      const r = pnlSheet.addRow(['  ' + a.accountName, a.netBalance]);
      r.getCell(2).numFmt = moneyFmt;
    });
    const expRow = pnlSheet.addRow(['Total Expenses', exportData.profitAndLoss.expenses.total]);
    expRow.font = { bold: true };
    expRow.getCell(2).numFmt = moneyFmt;
    expRow.getCell(2).font  = { bold: true, color: { argb: 'FFCC0000' } };

    pnlSheet.addRow([]);
    const netRow = pnlSheet.addRow([
      'NET PROFIT / (LOSS)',
      exportData.profitAndLoss.netProfit,
    ]);
    netRow.font = { bold: true, size: 12 };
    netRow.getCell(2).numFmt = moneyFmt;
    netRow.getCell(2).font   = {
      bold: true, size: 12,
      color: { argb: exportData.profitAndLoss.isProfitable ? 'FF006600' : 'FFCC0000' },
    };
    pnlSheet.getColumn(1).width = 30;
    pnlSheet.getColumn(2).width = 16;

    // ════════════════════════════════════════════════════════
    // SHEET 4 — BALANCE SHEET
    // ════════════════════════════════════════════════════════
    const bsSheet = wb.addWorksheet('Balance Sheet');
    const bs = exportData.balanceSheet;
    bsSheet.addRow([`Balance Sheet as at: ${bs.asOf}`]).font = { bold: true, size: 13 };
    bsSheet.addRow([]);

    const addBsSection = (label, accounts, total, color) => {
      bsSheet.addRow([label]).font = { bold: true };
      accounts.forEach(a => {
        const r = bsSheet.addRow(['  ' + a.accountName, a.netBalance]);
        r.getCell(2).numFmt = moneyFmt;
      });
      const totalRow = bsSheet.addRow([`Total ${label}`, total]);
      totalRow.font = { bold: true };
      totalRow.getCell(2).numFmt = moneyFmt;
      totalRow.getCell(2).font = { bold: true, color: { argb: color } };
      bsSheet.addRow([]);
    };

    addBsSection('Assets',      bs.assets.accounts,      bs.assets.total,      'FF005500');
    addBsSection('Liabilities', bs.liabilities.accounts, bs.liabilities.total, 'FF880000');
    addBsSection('Equity',      bs.equity.accounts,      bs.equity.total,      'FF000088');

    const netAssetsRow = bsSheet.addRow(['Net Assets (Assets − Liabilities)', bs.netAssets]);
    netAssetsRow.font = { bold: true, size: 12 };
    netAssetsRow.getCell(2).numFmt = moneyFmt;

    bsSheet.addRow([]);
    const balCheck = bsSheet.addRow([
      bs.isBalanced ? '✓ Balance sheet balances' : '✗ Balance sheet does NOT balance',
      bs.balanceCheck,
    ]);
    balCheck.font = {
      bold: true,
      color: { argb: bs.isBalanced ? 'FF006600' : 'FFCC0000' },
    };
    balCheck.getCell(2).numFmt = moneyFmt;
    bsSheet.getColumn(1).width = 36;
    bsSheet.getColumn(2).width = 16;

    // ════════════════════════════════════════════════════════
    // SHEET 5 — BUDGET
    // ════════════════════════════════════════════════════════
    const bgSheet = wb.addWorksheet('Budget', {
      views: [{ state: 'frozen', ySplit: 1 }],
    });
    bgSheet.columns = [
      { header: 'Category',  key: 'categoryName', width: 24 },
      { header: 'Type',      key: 'type',         width: 10 },
      { header: 'Budgeted',  key: 'budgeted',     width: 14 },
      { header: 'Actual',    key: 'actual',       width: 14 },
      { header: 'Variance',  key: 'variance',     width: 14 },
      { header: '% Used',    key: 'pctUsed',      width: 10 },
      { header: 'Status',    key: 'status',       width: 10 },
    ];
    styleHeader(bgSheet, bgSheet.getRow(1));

    exportData.budget.items.forEach(item => {
      const r = bgSheet.addRow({
        categoryName: item.categoryName,
        type:         item.isIncome ? 'Income' : 'Expense',
        budgeted:     item.budgeted,
        actual:       item.actual,
        variance:     item.variance,
        pctUsed:      item.pctUsed === Infinity ? 'N/A' : `${item.pctUsed}%`,
        status:       item.status.toUpperCase(),
      });
      ['budgeted','actual','variance'].forEach(k => r.getCell(k).numFmt = moneyFmt);

      // Colour status cell
      const statusColors = { over: 'FFFFE5E5', warning: 'FFFFF3CD', ok: 'FFE5F9EE', met: 'FFE5F9EE' };
      const sc = r.getCell('status');
      sc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: statusColors[item.status] || 'FFFFFFFF' } };
    });

    // ── Stream to response ──
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="FinBook_${period}.xlsx"`);
    await wb.xlsx.write(res);
    res.end();

  } catch (err) {
    console.error('[GET /reports/export] Error:', err.message);
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
