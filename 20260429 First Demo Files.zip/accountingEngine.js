/**
 * FinBook — Accounting Engine
 * ============================================================
 * Implements double-entry bookkeeping rules.
 *
 * Every transaction creates exactly TWO journal entries:
 *   1. A DEBIT to one account
 *   2. A CREDIT to another account
 *
 * The golden rules:
 *   Asset / Expense accounts  → Debit increases, Credit decreases
 *   Liability / Income / Equity → Credit increases, Debit decreases
 *
 * Example — user pays $241 rent (cash out):
 *   DR  Rent Paid (expense)    $241  ← expense goes up
 *   CR  Bank (asset)           $241  ← bank balance goes down
 *
 * Example — user receives $500 wages (cash in):
 *   DR  Bank (asset)           $500  ← bank balance goes up
 *   CR  Job / Wages (income)   $500  ← income goes up
 */

'use strict';

// ─────────────────────────────────────────────────────────────
//  ACCOUNT TYPE CONFIG
//  Defines which side INCREASES each account type.
// ─────────────────────────────────────────────────────────────
const NORMAL_SIDE = {
  asset:     'debit',   // DR increases assets
  expense:   'debit',   // DR increases expenses
  liability: 'credit',  // CR increases liabilities
  income:    'credit',  // CR increases income
  equity:    'credit',  // CR increases equity
};

// ─────────────────────────────────────────────────────────────
//  TRANSACTION TEMPLATES
//  Maps a transaction "type" to its DR and CR account types.
//  The app pre-populates these based on the selected category.
// ─────────────────────────────────────────────────────────────
const TRANSACTION_TEMPLATES = {
  // Cash OUT — expense payment
  expense: {
    debitType:  'expense',   // expense account goes up
    creditType: 'asset',     // bank / cash goes down
    description: 'Cash expense — DR expense, CR bank',
  },
  // Cash IN — income received
  income: {
    debitType:  'asset',     // bank goes up
    creditType: 'income',    // income account goes up
    description: 'Cash income — DR bank, CR income',
  },
  // Asset purchase (e.g. stock, equipment)
  asset_purchase: {
    debitType:  'asset',     // asset account goes up
    creditType: 'asset',     // bank goes down
    description: 'Asset purchase — DR asset, CR bank',
  },
  // Liability payment (e.g. mortgage repayment)
  liability_payment: {
    debitType:  'liability', // liability goes down (DR reduces liability)
    creditType: 'asset',     // bank goes down
    description: 'Liability payment — DR liability, CR bank',
  },
  // Receiving a loan
  loan_received: {
    debitType:  'asset',     // bank goes up
    creditType: 'liability', // liability goes up
    description: 'Loan received — DR bank, CR liability',
  },
  // Owner equity contribution
  equity_contribution: {
    debitType:  'asset',
    creditType: 'equity',
    description: 'Equity contribution — DR bank, CR equity',
  },
};

// ─────────────────────────────────────────────────────────────
//  JOURNAL ENTRY BUILDER
//  Creates a balanced pair of journal entries for a transaction.
//
//  @param {Object} params
//    txnId          - UUID of the transaction
//    userId         - UUID of the user
//    date           - JS Date or ISO string
//    debitAccountId - UUID of account to debit
//    creditAccountId- UUID of account to credit
//    amount         - positive number
//    description    - human-readable memo
//    period         - "2025-01"
//
//  @returns {Object[]} exactly two journal entry objects [DR, CR]
// ─────────────────────────────────────────────────────────────
function buildJournalEntries({
  txnId,
  userId,
  date,
  debitAccountId,
  creditAccountId,
  amount,
  description,
  period,
}) {
  if (!debitAccountId || !creditAccountId) {
    throw new Error('Both debitAccountId and creditAccountId are required.');
  }
  if (debitAccountId === creditAccountId) {
    throw new Error('Debit and credit accounts must be different.');
  }
  if (!amount || amount <= 0) {
    throw new Error(`Amount must be positive. Got: ${amount}`);
  }

  const entryDate = date instanceof Date ? date : new Date(date);

  return [
    {
      transaction_id:  txnId,
      user_id:         userId,
      entry_date:      entryDate,
      account_id:      debitAccountId,
      side:            'debit',
      amount:          roundCurrency(amount),
      description,
      period,
    },
    {
      transaction_id:  txnId,
      user_id:         userId,
      entry_date:      entryDate,
      account_id:      creditAccountId,
      side:            'credit',
      amount:          roundCurrency(amount),
      description,
      period,
    },
  ];
}

// ─────────────────────────────────────────────────────────────
//  TRANSACTION PROCESSOR
//  The main function called when a new transaction is saved.
//  Looks up accounts from DB, applies the right template,
//  returns journal entries ready to INSERT.
//
//  @param {Object} txn        - validated transaction from API
//  @param {Object} db         - database client (pg Pool)
//  @returns {Object[]}        - journal entries to insert
// ─────────────────────────────────────────────────────────────
async function processTransaction(txn, db) {
  const {
    id: txnId,
    user_id,
    txn_date,
    description,
    comment,
    debit_amount,
    credit_amount,
    category_id,
    period,
  } = txn;

  // Determine amount and direction
  const isExpense = !!debit_amount;
  const amount    = isExpense ? debit_amount : credit_amount;

  // Load category + linked account
  const category = await getCategoryWithAccount(category_id, db);
  if (!category) throw new Error(`Category ${category_id} not found.`);

  // Load the user's bank/cash account (the "other side" of the entry)
  const bankAccount = await getDefaultBankAccount(user_id, db);
  if (!bankAccount) throw new Error('No Bank account found. Please set up a Bank asset account.');

  // Determine DR and CR accounts based on transaction direction
  let debitAccountId, creditAccountId;

  if (isExpense) {
    // Cash OUT: DR the category's account (expense/liability), CR bank
    debitAccountId  = category.account_id;
    creditAccountId = bankAccount.id;
  } else {
    // Cash IN: DR bank, CR the category's account (income/asset)
    debitAccountId  = bankAccount.id;
    creditAccountId = category.account_id;
  }

  // Override for special account types
  const accountType = category.account_type;
  if (accountType === 'liability' && isExpense) {
    // Paying off a liability: DR liability (reduces it), CR bank
    debitAccountId  = category.account_id;
    creditAccountId = bankAccount.id;
  } else if (accountType === 'asset' && isExpense) {
    // Buying an asset with cash: DR asset, CR bank
    debitAccountId  = category.account_id;
    creditAccountId = bankAccount.id;
  } else if (accountType === 'liability' && !isExpense) {
    // Taking on a loan (cash in): DR bank, CR liability
    debitAccountId  = bankAccount.id;
    creditAccountId = category.account_id;
  }

  const memo = comment
    ? `${description} — ${comment}`
    : description;

  const entries = buildJournalEntries({
    txnId,
    userId:          user_id,
    date:            txn_date,
    debitAccountId,
    creditAccountId,
    amount,
    description:     memo,
    period,
  });

  // Sanity check — should always be true
  assertBalanced(entries);

  return entries;
}

// ─────────────────────────────────────────────────────────────
//  TRIAL BALANCE BUILDER
//  Aggregates journal entries into a trial balance object.
//  Can be called for any period or date range.
//
//  @param {string}   userId
//  @param {string}   period  - "2025-01" or null for all time
//  @param {Object}   db
//  @returns {Object} trial balance with totals per account
// ─────────────────────────────────────────────────────────────
async function buildTrialBalance(userId, period, db) {
  const params = [userId];
  let periodClause = '';
  if (period) {
    params.push(period);
    periodClause = `AND je.period = $${params.length}`;
  }

  const { rows } = await db.query(`
    SELECT
      a.id                AS account_id,
      a.name              AS account_name,
      a.type              AS account_type,
      a.normal_side,
      a.code,
      SUM(CASE WHEN je.side = 'debit'  THEN je.amount ELSE 0 END)  AS total_dr,
      SUM(CASE WHEN je.side = 'credit' THEN je.amount ELSE 0 END)  AS total_cr,
      -- Net balance on normal side
      CASE a.normal_side
        WHEN 'debit'  THEN SUM(CASE WHEN je.side = 'debit'  THEN je.amount ELSE -je.amount END)
        WHEN 'credit' THEN SUM(CASE WHEN je.side = 'credit' THEN je.amount ELSE -je.amount END)
      END                 AS net_balance
    FROM journal_entries je
    JOIN accounts a ON a.id = je.account_id
    WHERE je.user_id = $1
      ${periodClause}
    GROUP BY a.id, a.name, a.type, a.normal_side, a.code
    ORDER BY a.type, a.sort_order, a.name
  `, params);

  const totalDr = rows.reduce((s, r) => s + parseFloat(r.total_dr), 0);
  const totalCr = rows.reduce((s, r) => s + parseFloat(r.total_cr), 0);

  return {
    period:   period || 'all',
    accounts: rows.map(r => ({
      accountId:   r.account_id,
      accountName: r.account_name,
      accountType: r.account_type,
      normalSide:  r.normal_side,
      code:        r.code,
      totalDr:     roundCurrency(r.total_dr),
      totalCr:     roundCurrency(r.total_cr),
      netBalance:  roundCurrency(r.net_balance),
    })),
    totals: {
      totalDr:  roundCurrency(totalDr),
      totalCr:  roundCurrency(totalCr),
      balanced: Math.abs(totalDr - totalCr) < 0.01, // floating point tolerance
    },
  };
}

// ─────────────────────────────────────────────────────────────
//  PROFIT & LOSS BUILDER
//  Derives P&L from the trial balance.
//  Income accounts - Expense accounts = Net Profit/Loss
// ─────────────────────────────────────────────────────────────
async function buildProfitAndLoss(userId, period, db) {
  const tb = await buildTrialBalance(userId, period, db);

  const incomeAccounts  = tb.accounts.filter(a => a.accountType === 'income');
  const expenseAccounts = tb.accounts.filter(a => a.accountType === 'expense');

  const totalIncome   = sumBalances(incomeAccounts);
  const totalExpenses = sumBalances(expenseAccounts);
  const netProfit     = roundCurrency(totalIncome - totalExpenses);

  return {
    period,
    income: {
      accounts:     incomeAccounts,
      total:        roundCurrency(totalIncome),
    },
    expenses: {
      accounts:     expenseAccounts,
      total:        roundCurrency(totalExpenses),
    },
    netProfit,
    isProfitable:   netProfit >= 0,
    // Gross profit if cost of goods sold exists
    grossProfit:    calculateGrossProfit(incomeAccounts, expenseAccounts),
  };
}

// ─────────────────────────────────────────────────────────────
//  BALANCE SHEET BUILDER
//  Assets = Liabilities + Equity
//  Also folds in retained earnings (net profit) into equity.
// ─────────────────────────────────────────────────────────────
async function buildBalanceSheet(userId, period, db) {
  const tb = await buildTrialBalance(userId, period, db);
  const pnl = await buildProfitAndLoss(userId, period, db);

  const assetAccounts     = tb.accounts.filter(a => a.accountType === 'asset');
  const liabilityAccounts = tb.accounts.filter(a => a.accountType === 'liability');
  const equityAccounts    = tb.accounts.filter(a => a.accountType === 'equity');

  const totalAssets      = sumBalances(assetAccounts);
  const totalLiabilities = sumBalances(liabilityAccounts);
  const totalEquity      = sumBalances(equityAccounts) + pnl.netProfit; // retained earnings
  const balanceCheck     = roundCurrency(totalAssets - totalLiabilities - totalEquity);

  return {
    period,
    asOf: period ? `${period}-01` : new Date().toISOString().slice(0, 10),
    assets: {
      accounts: assetAccounts,
      total:    roundCurrency(totalAssets),
    },
    liabilities: {
      accounts: liabilityAccounts,
      total:    roundCurrency(totalLiabilities),
    },
    equity: {
      accounts:          equityAccounts,
      retainedEarnings:  roundCurrency(pnl.netProfit),
      total:             roundCurrency(totalEquity),
    },
    netAssets:    roundCurrency(totalAssets - totalLiabilities),
    balanceCheck, // should be 0.00 — if not, books don't balance
    isBalanced:   Math.abs(balanceCheck) < 0.01,
  };
}

// ─────────────────────────────────────────────────────────────
//  BUDGET VS ACTUAL
//  Compares budgeted amounts to real transaction totals.
// ─────────────────────────────────────────────────────────────
async function buildBudgetReport(userId, period, db) {
  const { rows } = await db.query(`
    SELECT
      b.category_id,
      c.name            AS category_name,
      c.is_income,
      b.budgeted_amount,
      COALESCE(
        SUM(COALESCE(t.debit_amount, t.credit_amount)), 0
      )                 AS actual_amount
    FROM budgets b
    JOIN categories c ON c.id = b.category_id
    LEFT JOIN transactions t
      ON  t.category_id = b.category_id
      AND t.period      = b.period
      AND t.user_id     = b.user_id
    WHERE b.user_id = $1
      AND b.period  = $2
    GROUP BY b.category_id, c.name, c.is_income, b.budgeted_amount
    ORDER BY c.is_income DESC, c.name
  `, [userId, period]);

  const items = rows.map(r => {
    const budgeted = parseFloat(r.budgeted_amount);
    const actual   = parseFloat(r.actual_amount);
    const variance = roundCurrency(budgeted - actual);
    const pctUsed  = budgeted > 0
      ? Math.round((actual / budgeted) * 100)
      : actual > 0 ? Infinity : 0;

    return {
      categoryId:   r.category_id,
      categoryName: r.category_name,
      isIncome:     r.is_income,
      budgeted:     roundCurrency(budgeted),
      actual:       roundCurrency(actual),
      variance,
      pctUsed,
      status:       getBudgetStatus(pctUsed, r.is_income),
    };
  });

  const totalBudgeted = items.reduce((s, i) => s + (i.isIncome ? 0 : i.budgeted), 0);
  const totalActual   = items.reduce((s, i) => s + (i.isIncome ? 0 : i.actual), 0);

  return {
    period,
    items,
    summary: {
      totalBudgetedExpenses: roundCurrency(totalBudgeted),
      totalActualExpenses:   roundCurrency(totalActual),
      totalVariance:         roundCurrency(totalBudgeted - totalActual),
      overBudgetCount:       items.filter(i => i.status === 'over').length,
    },
  };
}

// ─────────────────────────────────────────────────────────────
//  EXCEL EXPORT BUILDER
//  Produces structured data for ExcelJS to write a .xlsx
//  matching the original cashbook format.
// ─────────────────────────────────────────────────────────────
async function buildExcelExport(userId, period, db) {
  // Cash book rows
  const { rows: cashRows } = await db.query(`
    SELECT
      t.txn_date, t.description, t.comment,
      t.debit_amount, t.credit_amount, t.running_balance,
      c.name AS category
    FROM transactions t
    LEFT JOIN categories c ON c.id = t.category_id
    WHERE t.user_id = $1 AND t.period = $2
    ORDER BY t.txn_date, t.created_at
  `, [userId, period]);

  const pnl    = await buildProfitAndLoss(userId, period, db);
  const bs     = await buildBalanceSheet(userId, period, db);
  const budget = await buildBudgetReport(userId, period, db);
  const tb     = await buildTrialBalance(userId, period, db);

  return {
    cashBook:     cashRows,
    trialBalance: tb,
    profitAndLoss: pnl,
    balanceSheet: bs,
    budget,
  };
}

// ─────────────────────────────────────────────────────────────
//  PERIOD VALIDATOR
//  Derives period string from a date. Used on every transaction.
// ─────────────────────────────────────────────────────────────
function getPeriod(date) {
  const d = date instanceof Date ? date : new Date(date);
  const yyyy = d.getFullYear();
  const mm   = String(d.getMonth() + 1).padStart(2, '0');
  return `${yyyy}-${mm}`;
}

// ─────────────────────────────────────────────────────────────
//  JOURNAL BALANCE ASSERTION
//  Called after every journal build — throws if DR ≠ CR.
// ─────────────────────────────────────────────────────────────
function assertBalanced(entries) {
  const totalDr = entries
    .filter(e => e.side === 'debit')
    .reduce((s, e) => s + e.amount, 0);
  const totalCr = entries
    .filter(e => e.side === 'credit')
    .reduce((s, e) => s + e.amount, 0);

  if (Math.abs(totalDr - totalCr) > 0.01) {
    throw new Error(
      `Journal entries are unbalanced! DR=${totalDr} CR=${totalCr} diff=${totalDr - totalCr}`
    );
  }
  return true;
}

// ─────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────

function roundCurrency(n) {
  return Math.round(parseFloat(n || 0) * 100) / 100;
}

function sumBalances(accounts) {
  return accounts.reduce((s, a) => s + parseFloat(a.netBalance || 0), 0);
}

function getBudgetStatus(pctUsed, isIncome) {
  if (isIncome) {
    if (pctUsed >= 100) return 'met';
    if (pctUsed >= 75)  return 'near';
    return 'under';
  }
  if (pctUsed > 100)  return 'over';
  if (pctUsed >= 80)  return 'warning';
  return 'ok';
}

function calculateGrossProfit(incomeAccounts, expenseAccounts) {
  const revenue = incomeAccounts.reduce((s, a) => s + a.netBalance, 0);
  const cogs    = expenseAccounts
    .filter(a => a.accountName === 'Cost of Goods Sold')
    .reduce((s, a) => s + a.netBalance, 0);
  return roundCurrency(revenue - cogs);
}

// DB helpers — these hit the PostgreSQL accounts table
async function getCategoryWithAccount(categoryId, db) {
  const { rows } = await db.query(`
    SELECT c.id, c.name, c.account_id, c.is_income, a.type AS account_type
    FROM categories c
    JOIN accounts a ON a.id = c.account_id
    WHERE c.id = $1
  `, [categoryId]);
  return rows[0] || null;
}

async function getDefaultBankAccount(userId, db) {
  const { rows } = await db.query(`
    SELECT id, name, type FROM accounts
    WHERE user_id = $1 AND name = 'Bank' AND type = 'asset'
    LIMIT 1
  `, [userId]);
  return rows[0] || null;
}

// ─────────────────────────────────────────────────────────────
//  MODULE EXPORTS
// ─────────────────────────────────────────────────────────────
module.exports = {
  // Core
  buildJournalEntries,
  processTransaction,
  assertBalanced,
  getPeriod,
  // Reports
  buildTrialBalance,
  buildProfitAndLoss,
  buildBalanceSheet,
  buildBudgetReport,
  buildExcelExport,
  // Constants (useful for seeding / UI)
  NORMAL_SIDE,
  TRANSACTION_TEMPLATES,
};
