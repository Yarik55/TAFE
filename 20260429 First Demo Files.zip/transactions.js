/**
 * FinBook — Transaction API Route
 * POST   /api/transactions        → create + auto-journal
 * GET    /api/transactions        → list (paginated, filterable)
 * GET    /api/transactions/:id    → single
 * DELETE /api/transactions/:id    → soft delete + reverse journals
 */

'use strict';

const express = require('express');
const router  = express.Router();
const { v4: uuidv4 } = require('uuid');
const engine  = require('../engine/accountingEngine');

// ─────────────────────────────────────────────────────────────
//  POST /api/transactions
//  Creates a transaction AND its journal entries atomically.
// ─────────────────────────────────────────────────────────────
router.post('/', async (req, res) => {
  const db     = req.app.locals.db;  // pg Pool attached in app.js
  const userId = req.user.id;        // set by auth middleware

  // 1. Validate input
  const validation = validateTransaction(req.body);
  if (!validation.ok) {
    return res.status(400).json({ error: validation.error });
  }

  const {
    txn_date,
    description,
    comment,
    debit_amount,
    credit_amount,
    category_id,
    source = 'manual',
    ocr_image_url,
    ocr_raw_text,
  } = req.body;

  const period = engine.getPeriod(txn_date);
  const txnId  = uuidv4();

  // 2. Run everything in a transaction (atomic — if journal fails, row is rolled back)
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    // Insert the cash book row
    const { rows: [txn] } = await client.query(`
      INSERT INTO transactions (
        id, user_id, txn_date, description, comment,
        debit_amount, credit_amount, category_id,
        source, ocr_image_url, ocr_raw_text, period
      ) VALUES (
        $1, $2, $3, $4, $5,
        $6, $7, $8,
        $9, $10, $11, $12
      ) RETURNING *
    `, [
      txnId, userId, txn_date, description, comment || null,
      debit_amount || null, credit_amount || null, category_id,
      source, ocr_image_url || null, ocr_raw_text || null, period,
    ]);

    // Generate journal entries via the accounting engine
    const journalEntries = await engine.processTransaction(txn, client);

    // Insert journal entries
    for (const entry of journalEntries) {
      await client.query(`
        INSERT INTO journal_entries (
          transaction_id, user_id, entry_date,
          account_id, side, amount, description, period
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [
        entry.transaction_id, entry.user_id, entry.entry_date,
        entry.account_id, entry.side, entry.amount,
        entry.description, entry.period,
      ]);
    }

    await client.query('COMMIT');

    // Return the saved transaction + its journal entries
    return res.status(201).json({
      transaction:    txn,
      journalEntries: journalEntries,
    });

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('[POST /transactions] Error:', err.message);

    // Surface accounting errors clearly (e.g. unbalanced journals)
    if (err.message.includes('unbalanced') || err.message.includes('account')) {
      return res.status(422).json({ error: `Accounting error: ${err.message}` });
    }
    return res.status(500).json({ error: 'Failed to save transaction.' });

  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────
//  GET /api/transactions
//  Returns paginated cash book rows for a period.
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  const db     = req.app.locals.db;
  const userId = req.user.id;
  const {
    period,
    category_id,
    page  = 1,
    limit = 50,
  } = req.query;

  const offset = (parseInt(page) - 1) * parseInt(limit);
  const params = [userId];
  const filters = [];

  if (period) {
    params.push(period);
    filters.push(`t.period = $${params.length}`);
  }
  if (category_id) {
    params.push(category_id);
    filters.push(`t.category_id = $${params.length}`);
  }

  const where = filters.length ? `AND ${filters.join(' AND ')}` : '';

  const { rows } = await db.query(`
    SELECT
      t.*,
      c.name  AS category_name,
      c.color AS category_color,
      c.icon  AS category_icon
    FROM transactions t
    LEFT JOIN categories c ON c.id = t.category_id
    WHERE t.user_id = $1
      ${where}
    ORDER BY t.txn_date DESC, t.created_at DESC
    LIMIT ${parseInt(limit)} OFFSET ${offset}
  `, params);

  // Total count for pagination
  const { rows: [{ count }] } = await db.query(`
    SELECT COUNT(*) FROM transactions t
    WHERE t.user_id = $1 ${where}
  `, params);

  return res.json({
    data:       rows,
    pagination: {
      page:       parseInt(page),
      limit:      parseInt(limit),
      total:      parseInt(count),
      totalPages: Math.ceil(parseInt(count) / parseInt(limit)),
    },
  });
});

// ─────────────────────────────────────────────────────────────
//  GET /api/transactions/:id
// ─────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  const db     = req.app.locals.db;
  const userId = req.user.id;

  const { rows: [txn] } = await db.query(`
    SELECT t.*, c.name AS category_name
    FROM transactions t
    LEFT JOIN categories c ON c.id = t.category_id
    WHERE t.id = $1 AND t.user_id = $2
  `, [req.params.id, userId]);

  if (!txn) return res.status(404).json({ error: 'Transaction not found.' });

  // Fetch its journal entries for audit display
  const { rows: journals } = await db.query(`
    SELECT je.*, a.name AS account_name, a.type AS account_type
    FROM journal_entries je
    JOIN accounts a ON a.id = je.account_id
    WHERE je.transaction_id = $1
    ORDER BY je.side DESC
  `, [req.params.id]);

  return res.json({ transaction: txn, journalEntries: journals });
});

// ─────────────────────────────────────────────────────────────
//  DELETE /api/transactions/:id
//  Reverses the transaction with a counter-entry (audit trail).
//  Hard delete is intentionally not offered — accounting audit.
// ─────────────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  const db     = req.app.locals.db;
  const userId = req.user.id;
  const client = await db.connect();

  try {
    await client.query('BEGIN');

    // Load original transaction
    const { rows: [original] } = await client.query(`
      SELECT * FROM transactions WHERE id = $1 AND user_id = $2
    `, [req.params.id, userId]);

    if (!original) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Transaction not found.' });
    }

    // Create a reversal transaction (negates the original)
    const reversalId = uuidv4();
    await client.query(`
      INSERT INTO transactions (
        id, user_id, txn_date, description, comment,
        debit_amount, credit_amount, category_id, source, period
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, 'manual', $9
      )
    `, [
      reversalId, userId, new Date().toISOString().slice(0, 10),
      `REVERSAL: ${original.description}`,
      `Reversal of transaction ${original.id}`,
      // Swap debit/credit to reverse
      original.credit_amount,  // original CR becomes DR
      original.debit_amount,   // original DR becomes CR
      original.category_id,
      engine.getPeriod(new Date()),
    ]);

    // Generate and insert reversal journal entries
    const { rows: [reversalTxn] } = await client.query(
      `SELECT * FROM transactions WHERE id = $1`, [reversalId]
    );
    const reversalEntries = await engine.processTransaction(reversalTxn, client);
    for (const entry of reversalEntries) {
      await client.query(`
        INSERT INTO journal_entries (
          transaction_id, user_id, entry_date,
          account_id, side, amount, description, period
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [
        entry.transaction_id, entry.user_id, entry.entry_date,
        entry.account_id, entry.side, entry.amount,
        entry.description, entry.period,
      ]);
    }

    // Mark original as reconciled/voided (never hard delete)
    await client.query(`
      UPDATE transactions SET is_reconciled = TRUE, comment = $1
      WHERE id = $2
    `, [`VOIDED — reversed by ${reversalId}`, original.id]);

    await client.query('COMMIT');

    return res.json({
      message:    'Transaction reversed.',
      reversalId,
    });

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('[DELETE /transactions] Error:', err.message);
    return res.status(500).json({ error: 'Failed to reverse transaction.' });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────
//  INPUT VALIDATOR
// ─────────────────────────────────────────────────────────────
function validateTransaction(body) {
  const { txn_date, description, debit_amount, credit_amount, category_id } = body;

  if (!txn_date)    return { ok: false, error: 'txn_date is required.' };
  if (!description) return { ok: false, error: 'description is required.' };
  if (!category_id) return { ok: false, error: 'category_id is required.' };

  if (!debit_amount && !credit_amount) {
    return { ok: false, error: 'Either debit_amount or credit_amount is required.' };
  }
  if (debit_amount && credit_amount) {
    return { ok: false, error: 'Provide only debit_amount OR credit_amount, not both.' };
  }
  const amount = parseFloat(debit_amount || credit_amount);
  if (isNaN(amount) || amount <= 0) {
    return { ok: false, error: 'Amount must be a positive number.' };
  }
  if (isNaN(new Date(txn_date).getTime())) {
    return { ok: false, error: 'txn_date is not a valid date.' };
  }

  return { ok: true };
}

module.exports = router;
