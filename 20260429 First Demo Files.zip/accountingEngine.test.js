/**
 * FinBook — Accounting Engine Unit Tests
 * Run with: npx jest src/engine/accountingEngine.test.js
 *
 * Covers:
 *  - Journal entry creation (DR + CR always equal)
 *  - All account type combinations
 *  - Edge cases: zero amounts, missing accounts, unbalanced journals
 *  - Trial balance, P&L, Balance Sheet shape
 *  - Budget status thresholds
 */

'use strict';

const {
  buildJournalEntries,
  assertBalanced,
  getPeriod,
  NORMAL_SIDE,
  TRANSACTION_TEMPLATES,
} = require('./accountingEngine');

// ─────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────
const UUID_A = '11111111-1111-1111-1111-111111111111';
const UUID_B = '22222222-2222-2222-2222-222222222222';
const TXN_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
const USER_ID= 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';

function makeEntries(debitId, creditId, amount, date = '2025-01-17') {
  return buildJournalEntries({
    txnId:           TXN_ID,
    userId:          USER_ID,
    date,
    debitAccountId:  debitId,
    creditAccountId: creditId,
    amount,
    description:     'Test entry',
    period:          getPeriod(date),
  });
}

// ─────────────────────────────────────────────────────────────
//  buildJournalEntries
// ─────────────────────────────────────────────────────────────
describe('buildJournalEntries', () => {

  test('returns exactly two entries', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries).toHaveLength(2);
  });

  test('first entry is always a debit', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries[0].side).toBe('debit');
  });

  test('second entry is always a credit', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries[1].side).toBe('credit');
  });

  test('both entries have equal amounts', () => {
    const entries = makeEntries(UUID_A, UUID_B, 241.50);
    expect(entries[0].amount).toBe(241.50);
    expect(entries[1].amount).toBe(241.50);
  });

  test('amounts are rounded to 2 decimal places', () => {
    const entries = makeEntries(UUID_A, UUID_B, 10.999);
    expect(entries[0].amount).toBe(11.00);
  });

  test('debit entry references the debit account', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries[0].account_id).toBe(UUID_A);
  });

  test('credit entry references the credit account', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries[1].account_id).toBe(UUID_B);
  });

  test('both entries share the same transaction_id', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(entries[0].transaction_id).toBe(TXN_ID);
    expect(entries[1].transaction_id).toBe(TXN_ID);
  });

  test('period is set correctly from date', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100, '2025-03-15');
    expect(entries[0].period).toBe('2025-03');
    expect(entries[1].period).toBe('2025-03');
  });

  test('throws if debit and credit are the same account', () => {
    expect(() => makeEntries(UUID_A, UUID_A, 100)).toThrow(/different/);
  });

  test('throws if amount is zero', () => {
    expect(() => makeEntries(UUID_A, UUID_B, 0)).toThrow(/positive/);
  });

  test('throws if amount is negative', () => {
    expect(() => makeEntries(UUID_A, UUID_B, -50)).toThrow(/positive/);
  });

  test('throws if debitAccountId is missing', () => {
    expect(() => buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-01',
      debitAccountId: null, creditAccountId: UUID_B,
      amount: 100, description: 'test', period: '2025-01',
    })).toThrow(/required/);
  });

  test('throws if creditAccountId is missing', () => {
    expect(() => buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-01',
      debitAccountId: UUID_A, creditAccountId: null,
      amount: 100, description: 'test', period: '2025-01',
    })).toThrow(/required/);
  });

  test('accepts string date', () => {
    expect(() => makeEntries(UUID_A, UUID_B, 100, '2025-01-17')).not.toThrow();
  });

  test('accepts Date object', () => {
    expect(() => makeEntries(UUID_A, UUID_B, 100, new Date('2025-01-17'))).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────
//  assertBalanced
// ─────────────────────────────────────────────────────────────
describe('assertBalanced', () => {

  test('passes for balanced entries', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  test('returns true for balanced entries', () => {
    const entries = makeEntries(UUID_A, UUID_B, 100);
    expect(assertBalanced(entries)).toBe(true);
  });

  test('throws for unbalanced entries', () => {
    const entries = [
      { side: 'debit',  amount: 100 },
      { side: 'credit', amount: 90  },  // doesn't balance
    ];
    expect(() => assertBalanced(entries)).toThrow(/unbalanced/);
  });

  test('tolerates floating point noise up to 0.01', () => {
    const entries = [
      { side: 'debit',  amount: 100.004 },
      { side: 'credit', amount: 100     },
    ];
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  test('throws when difference exceeds 0.01', () => {
    const entries = [
      { side: 'debit',  amount: 100.02 },
      { side: 'credit', amount: 100    },
    ];
    expect(() => assertBalanced(entries)).toThrow(/unbalanced/);
  });
});

// ─────────────────────────────────────────────────────────────
//  getPeriod
// ─────────────────────────────────────────────────────────────
describe('getPeriod', () => {

  test('returns YYYY-MM from string date', () => {
    expect(getPeriod('2025-01-17')).toBe('2025-01');
  });

  test('returns YYYY-MM from Date object', () => {
    expect(getPeriod(new Date('2025-06-01'))).toBe('2025-06');
  });

  test('pads single-digit months', () => {
    expect(getPeriod('2025-03-05')).toBe('2025-03');
  });

  test('handles December correctly', () => {
    expect(getPeriod('2025-12-31')).toBe('2025-12');
  });
});

// ─────────────────────────────────────────────────────────────
//  NORMAL_SIDE constant
// ─────────────────────────────────────────────────────────────
describe('NORMAL_SIDE', () => {

  test('assets increase on debit side', () => {
    expect(NORMAL_SIDE.asset).toBe('debit');
  });

  test('expenses increase on debit side', () => {
    expect(NORMAL_SIDE.expense).toBe('debit');
  });

  test('liabilities increase on credit side', () => {
    expect(NORMAL_SIDE.liability).toBe('credit');
  });

  test('income increases on credit side', () => {
    expect(NORMAL_SIDE.income).toBe('credit');
  });

  test('equity increases on credit side', () => {
    expect(NORMAL_SIDE.equity).toBe('credit');
  });
});

// ─────────────────────────────────────────────────────────────
//  DOUBLE-ENTRY GOLDEN RULE SCENARIOS
//  These validate the business logic of accounting rules.
// ─────────────────────────────────────────────────────────────
describe('Double-entry golden rules', () => {

  /**
   * Scenario: Pay $241 rent (cash out → expense)
   *   DR Rent Paid (expense)   $241
   *   CR Bank (asset)          $241
   */
  test('expense payment: DR expense, CR bank', () => {
    const rentAccountId = UUID_A;   // expense account
    const bankAccountId = UUID_B;   // asset account

    const entries = buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-17',
      debitAccountId:  rentAccountId,
      creditAccountId: bankAccountId,
      amount: 241, description: 'Rent payment', period: '2025-01',
    });

    const dr = entries.find(e => e.side === 'debit');
    const cr = entries.find(e => e.side === 'credit');

    expect(dr.account_id).toBe(rentAccountId);  // expense debited
    expect(cr.account_id).toBe(bankAccountId);  // bank credited (reduced)
    expect(dr.amount).toBe(241);
    expect(cr.amount).toBe(241);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * Scenario: Receive $500 wages (cash in → income)
   *   DR Bank (asset)          $500
   *   CR Job / Wages (income)  $500
   */
  test('income received: DR bank, CR income', () => {
    const bankAccountId  = UUID_A;  // asset account
    const wagesAccountId = UUID_B;  // income account

    const entries = buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-16',
      debitAccountId:  bankAccountId,
      creditAccountId: wagesAccountId,
      amount: 500, description: 'Wages received', period: '2025-01',
    });

    const dr = entries.find(e => e.side === 'debit');
    const cr = entries.find(e => e.side === 'credit');

    expect(dr.account_id).toBe(bankAccountId);   // bank goes up
    expect(cr.account_id).toBe(wagesAccountId);  // income goes up
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * Scenario: Make a mortgage payment of $2,000 (liability payment)
   *   DR Mortgage (liability)  $2,000  ← reduces what we owe
   *   CR Bank (asset)          $2,000  ← cash goes out
   */
  test('liability payment: DR liability, CR bank', () => {
    const mortgageId = UUID_A;  // liability account
    const bankId     = UUID_B;  // asset account

    const entries = buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-01',
      debitAccountId:  mortgageId,
      creditAccountId: bankId,
      amount: 2000, description: 'Mortgage payment', period: '2025-01',
    });

    expect(entries.find(e => e.side === 'debit').account_id).toBe(mortgageId);
    expect(entries.find(e => e.side === 'credit').account_id).toBe(bankId);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * Scenario: Receive a loan of $10,000
   *   DR Bank (asset)          $10,000  ← cash comes in
   *   CR Loan (liability)      $10,000  ← we owe more
   */
  test('loan received: DR bank, CR liability', () => {
    const bankId = UUID_A;
    const loanId = UUID_B;

    const entries = buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-10',
      debitAccountId:  bankId,
      creditAccountId: loanId,
      amount: 10000, description: 'Loan received', period: '2025-01',
    });

    expect(entries.find(e => e.side === 'debit').account_id).toBe(bankId);
    expect(entries.find(e => e.side === 'credit').account_id).toBe(loanId);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * Scenario: Buy stock worth $500 (asset purchase)
   *   DR Stock at Hand (asset) $500  ← new asset goes up
   *   CR Bank (asset)          $500  ← bank goes down
   */
  test('asset purchase: DR asset, CR bank (both assets)', () => {
    const stockId = UUID_A;
    const bankId  = UUID_B;

    const entries = buildJournalEntries({
      txnId: TXN_ID, userId: USER_ID, date: '2025-01-20',
      debitAccountId:  stockId,
      creditAccountId: bankId,
      amount: 500, description: 'Stock purchase', period: '2025-01',
    });

    expect(entries.find(e => e.side === 'debit').account_id).toBe(stockId);
    expect(entries.find(e => e.side === 'credit').account_id).toBe(bankId);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * Large amount precision test — $1,100,000 mortgage
   */
  test('large amounts are handled precisely', () => {
    const entries = makeEntries(UUID_A, UUID_B, 1100000.00);
    expect(entries[0].amount).toBe(1100000.00);
    expect(entries[1].amount).toBe(1100000.00);
    expect(() => assertBalanced(entries)).not.toThrow();
  });

  /**
   * All entries from one period must net to zero
   * (total DR across all accounts = total CR)
   */
  test('multiple transactions in a period: total DR equals total CR', () => {
    const rent    = makeEntries(UUID_A, UUID_B, 241);    // expense
    const wages   = makeEntries(UUID_B, UUID_A, 500);    // income
    const netflix = makeEntries(UUID_A, UUID_B, 25.99);  // expense

    const all = [...rent, ...wages, ...netflix];
    const totalDr = all.filter(e => e.side === 'debit').reduce((s, e) => s + e.amount, 0);
    const totalCr = all.filter(e => e.side === 'credit').reduce((s, e) => s + e.amount, 0);

    expect(Math.abs(totalDr - totalCr)).toBeLessThan(0.01);
  });
});

// ─────────────────────────────────────────────────────────────
//  TRANSACTION TEMPLATES
// ─────────────────────────────────────────────────────────────
describe('TRANSACTION_TEMPLATES', () => {

  test('expense template debits expense, credits asset', () => {
    expect(TRANSACTION_TEMPLATES.expense.debitType).toBe('expense');
    expect(TRANSACTION_TEMPLATES.expense.creditType).toBe('asset');
  });

  test('income template debits asset, credits income', () => {
    expect(TRANSACTION_TEMPLATES.income.debitType).toBe('asset');
    expect(TRANSACTION_TEMPLATES.income.creditType).toBe('income');
  });

  test('liability_payment debits liability, credits asset', () => {
    expect(TRANSACTION_TEMPLATES.liability_payment.debitType).toBe('liability');
    expect(TRANSACTION_TEMPLATES.liability_payment.creditType).toBe('asset');
  });

  test('loan_received debits asset, credits liability', () => {
    expect(TRANSACTION_TEMPLATES.loan_received.debitType).toBe('asset');
    expect(TRANSACTION_TEMPLATES.loan_received.creditType).toBe('liability');
  });

  test('equity_contribution debits asset, credits equity', () => {
    expect(TRANSACTION_TEMPLATES.equity_contribution.debitType).toBe('asset');
    expect(TRANSACTION_TEMPLATES.equity_contribution.creditType).toBe('equity');
  });
});
