/**
 * FinBook — Express App Entry Point
 */
'use strict';

require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const helmet       = require('helmet');
const { Pool }     = require('pg');

// Routes
const transactionsRouter = require('./routes/transactions');
const reportsRouter      = require('./routes/reports');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ───────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') || '*' }));
app.use(express.json());

// ── Database Pool ────────────────────────────────────────────
const db = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
});
app.locals.db = db;

// ── Auth middleware (stub — replace with Clerk/Supabase JWT) ─
app.use((req, res, next) => {
  // TODO: verify JWT from Authorization header
  // For now, attach a dev user
  req.user = { id: process.env.DEV_USER_ID || 'dev-user-id' };
  next();
});

// ── Routes ───────────────────────────────────────────────────
app.use('/api/transactions', transactionsRouter);
app.use('/api/reports',      reportsRouter);

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ── 404 + Error handlers ─────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Route not found.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`FinBook API running on port ${PORT}`);
});

module.exports = app;
